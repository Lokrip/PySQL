from PySql.logs.log import errors

DATABASE_NOT_FOUND = errors.database_error()