class Utils:
    def __init__(self) -> None:
        pass
    
    